======
Sudoku
======

Sudoku game implemented with pyQt.

.. image:: https://raw.github.com/aaahexing/Sudoku/master/_static/screenshots/sudoku.png

========
Features
========

* Simple algorithm for puzzles' generation from this blog_

.. _blog: http://dryicons.com/blog/2009/08/14/a-simple-algorithm-for-generating-sudoku-puzzles/

